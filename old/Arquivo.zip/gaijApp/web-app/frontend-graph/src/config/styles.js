export const nodeStyles = {
  Person: {
    fill_color: '#4CAF50',
    text_color: '#FFFFFF'
  },
  Company: {
    fill_color: '#2196F3',
    text_color: '#FFFFFF'
  },
  Address: {
    fill_color: '#FFC107',
    text_color: '#000000'
  }
};